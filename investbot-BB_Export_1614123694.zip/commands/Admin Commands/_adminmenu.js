/*CMD
  command: /adminmenu
  help: 
  need_reply: false
  auto_retry_time: 
  folder: Admin Commands

  <<ANSWER

  ANSWER
  keyboard: 
  aliases: admin menu, 📲 administracion 📲
CMD*/

var admin = user.telegramid

if (admin == 1290520197) {
  Bot.runCommand("/itsmypasssssssbsjdjdvsjsjsvdhiddjlabacs")
} else {
  Bot.runCommand("OpenHome")
}

