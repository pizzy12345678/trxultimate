/*CMD
  command: ⭐⭐⭐⭐⭐
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admin Commands
  answer: ....
  keyboard: ⭐ saldo, ⭐ deposito, \n⭐ reinversion, ⭐ check,\nback 🔙
  aliases: 
CMD*/

