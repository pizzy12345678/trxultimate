/*CMD
  command: /backtomenu
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admin Commands
  answer: 
  keyboard: 
  aliases: back to menu, 🔚 salir
CMD*/

Bot.runCommand("OpenHome")

