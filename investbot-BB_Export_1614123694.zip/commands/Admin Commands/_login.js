/*CMD
  command: /login
  help: 
  need_reply: true
  auto_retry_time: 
  folder: Admin Commands
  answer: 📬 Si Esta funcion no es activada, No podra recibir Mensajes de los miembros Del Bot, Por favor introduzca su Clave :
  keyboard: 
  aliases: login, 📬 login 📬
CMD*/

// Automatic fix
var msg

// Automatic fix
var msg

// Automatic fix
var msg

msg = "Access denied, Wrong Password"

if (message == "AuraAdmi") {
  Bot.setProperty("admin_chat", chat.chatid, "string")
  msg = "You admin now. Please wait messages from users"
}

Bot.sendMessage(msg)

