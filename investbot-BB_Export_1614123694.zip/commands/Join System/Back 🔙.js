/*CMD
  command: Back 🔙
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Join System
  answer: 
  keyboard: 
  aliases: back 🔙
CMD*/

var message = data.message;
if(data.message=="Back 🔙"){
Bot.runCommand("OpenHome")
}
