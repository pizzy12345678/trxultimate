/*CMD
  command: /onPermanentWalletIPN
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Coinpayment
  answer: 
  keyboard: 
  aliases: 
CMD*/

//Bot.sendMessage("IPN called: ");
//Bot.sendMessage(inspect(options));
