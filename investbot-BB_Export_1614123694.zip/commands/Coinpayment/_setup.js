/*CMD
  command: /setup
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Coinpayment
  answer: 😁
  keyboard: 
  aliases: 
CMD*/

Libs.CoinPayments.setPrivateKey('835eb6a301b539fC1D29BbeadF124a2F8c2fd84d88d5DcB3C85a7462d1348eA1');
Libs.CoinPayments.setPublicKey('74bad77c75408506fe31049024d300d176f87c693aabb01fb6cd4510dbf91176');
Libs.CoinPayments.setBBApiKey('Mfjsj-ttdjTfQu4dp8B64JGcVUBW2kzFGRPUayvv');
