/*CMD
  command: 💲 Saldo
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admin panel
  answer: Check o cambie saldo
  keyboard: 💲 cambiar, 💲 check, \n⭐🔙
  aliases: 💲 saldo
CMD*/

