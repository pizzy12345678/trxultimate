/*CMD
  command: ⭐🔙
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admin panel
  answer: Bienvenido Etc.. Este panel es unico XD, desde aca controlaras los balances 🙃
  keyboard: 💲 saldo,💲 deposito,\n💲 reinversion,📲 panel 
  aliases: 
CMD*/

