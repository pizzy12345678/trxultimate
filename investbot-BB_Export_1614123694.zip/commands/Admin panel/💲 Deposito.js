/*CMD
  command: 💲 Deposito
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admin panel
  answer: Check o cambie los depositos activos
  keyboard: ➕ cambiar, ➕ check, \n⭐🔙
  aliases: 💲 deposito
CMD*/

