/*CMD
  command: 💲 Reinversion
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admin panel
  answer: Check o cambie las reinversiones 
  keyboard: 💳 cambiar, 💳 check, \n⭐🔙
  aliases: 💲 reinversion
CMD*/

