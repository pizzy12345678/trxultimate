/*CMD
  command: /home2
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Buttons
  answer: 
  keyboard: 
  aliases: 💻 details
CMD*/

Bot.sendMessage("*👩‍🚀User Details\n\n Name :- "+user.first_name+"\n\n🤴 Username :@" +user.username+"\n\n 🆔 User ID : "+user.telegramid+"*")
