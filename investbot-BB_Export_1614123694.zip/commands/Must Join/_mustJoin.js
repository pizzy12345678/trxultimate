/*CMD
  command: /mustJoin
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Must Join
  answer: 
  keyboard: 
  aliases: 
CMD*/

Bot.runCommand("/start");
