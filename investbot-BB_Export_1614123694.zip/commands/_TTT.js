/*CMD
  command: /TTT
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

BBAdmin.installBot({
  email: 'manu38ale@gmail.com',
  bot_id: 192707
})
