/*CMD
  command: /admi2
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admi2
  answer: Xd mira tu panel 🙃 sencillo pero puff, hace cosas que otros no pueden ⭐⭐⭐ envia bot, canal y ademas podras check y cambiar cualquier saldo : Reinversion Depositos y Para retirar 
  keyboard: ⭐🔙,⭐ bot,⭐ canal,\nBack 🔙
  aliases: 📲 panel, ⭐
CMD*/

