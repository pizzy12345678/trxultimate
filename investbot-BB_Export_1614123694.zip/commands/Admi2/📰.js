/*CMD
  command: 📰
  help: 
  need_reply: 
  auto_retry_time: 
  folder: Admi2
  answer: 
  keyboard: 
  aliases: 
CMD*/

var admin = user.telegramid

if (admin == 1290520197) {
  Bot.runCommand("/admi2")
} else {
  Bot.runCommand("OpenHome")
}
